// Write out standard footer and links
document.write('Copyright &copy; 2013-2022 <a href="https://www.ddginc-usa.com/">Data Design Group, Inc.</a> All Rights Reserved');
document.write( '<span class="pull-right">')
document.write( '&nbsp; <a href="https://www.facebook.com/convertcsv">Facebook</a>')
document.write(' &nbsp; <a href="https://twitter.com/ConvertCsv">Twitter</a>');
document.write(' &nbsp; <a href="/PrivacyPolicy.htm">Privacy Policy</a>');
document.write(' &nbsp; <a href="/contact.htm">Contact Us</a>');
document.write(' &nbsp; <a href="changelog.htm">Change Log</a>');
document.write(' &nbsp; <a href="/terms-of-use.htm">Terms of Use</a>');
document.write(' &nbsp; <a href="/index.html">Home</a></span>');